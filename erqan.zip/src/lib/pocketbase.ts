import PocketBase from 'pocketbase';

export const pb = new PocketBase('http://31.97.37.128:8090');

// Timeout ve retry ayarları
pb.beforeSend = function(url, options) {
  options.timeout = 10000; // 10 saniye timeout
  return { url, options };
};

export type AuthModel = {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  credit?: number;
  rent_paid?: number;
  created: string;
  updated: string;
}; 